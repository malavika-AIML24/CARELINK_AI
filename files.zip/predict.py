"""
CARELINK AI - Risk Prediction Module
Uses ML model to predict health risk based on vitals
"""

import joblib
import numpy as np
from pathlib import Path

class RiskPredictor:
    """Predicts health risk using trained ML model"""
    
    def __init__(self, model_path="backend/model.pkl"):
        """Load pre-trained ML model"""
        try:
            self.model = joblib.load(model_path)
            self.model_loaded = True
        except FileNotFoundError:
            print(f"⚠️  Model not found at {model_path}. Using fallback risk calculation.")
            self.model_loaded = False
    
    def predict_risk(self, heart_rate, temperature, spo2):
        """
        Predict risk level based on vital signs
        Returns: "NORMAL" or "HIGH RISK"
        """
        
        if self.model_loaded:
            # Use ML model for prediction
            features = np.array([[heart_rate, temperature, spo2]])
            prediction = self.model.predict(features)[0]
            risk_score = self.model.predict_proba(features)[0]
            
            risk_level = "HIGH RISK" if prediction == 1 else "NORMAL"
            confidence = max(risk_score) * 100
        else:
            # Fallback: Rule-based risk assessment
            risk_score = 0
            
            # Heart rate risk
            if heart_rate < 50 or heart_rate > 120:
                risk_score += 2
            elif heart_rate < 60 or heart_rate > 100:
                risk_score += 1
            
            # Temperature risk
            if temperature < 35.0 or temperature > 39.0:
                risk_score += 2
            elif temperature < 36.0 or temperature > 38.5:
                risk_score += 1
            
            # SpO2 risk
            if spo2 < 85:
                risk_score += 3
            elif spo2 < 90:
                risk_score += 2
            elif spo2 < 95:
                risk_score += 1
            
            risk_level = "HIGH RISK" if risk_score >= 3 else "NORMAL"
            confidence = (risk_score / 6) * 100 if risk_score > 0 else 0
        
        return {
            "risk_level": risk_level,
            "confidence": round(confidence, 2),
            "heart_rate": heart_rate,
            "temperature": temperature,
            "spo2": spo2
        }
    
    def get_risk_color(self, risk_level):
        """Return color code for risk level"""
        return "#FF4444" if risk_level == "HIGH RISK" else "#44FF44"