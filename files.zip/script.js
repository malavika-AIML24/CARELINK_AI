/**
 * CARELINK AI - Frontend Utility Functions
 */

const API_BASE_URL = 'http://127.0.0.1:5000';

/**
 * Check if user is authenticated
 * Redirect to login if not
 */
function checkAuth() {
    const user = localStorage.getItem('user');
    if (!user) {
        window.location.href = 'index.html';
    } else {
        const userObj = JSON.parse(user);
        document.getElementById('userInfo').textContent = `${userObj.role.toUpperCase()} - ${userObj.username}`;
    }
}

/**
 * Logout user
 */
async function logout() {
    try {
        await fetch(`${API_BASE_URL}/auth/logout`, {
            method: 'POST'
        });
    } catch (error) {
        console.error('Logout error:', error);
    } finally {
        localStorage.removeItem('user');
        localStorage.removeItem('selectedPatientId');
        window.location.href = 'index.html';
    }
}

/**
 * Format timestamp to readable format
 */
function formatTime(timestamp) {
    return new Date(timestamp).toLocaleTimeString();
}

/**
 * Get risk level color
 */
function getRiskColor(riskLevel) {
    return riskLevel === 'HIGH RISK' ? '#FF4444' : '#44FF44';
}

/**
 * Handle API errors
 */
function handleAPIError(error) {
    console.error('API Error:', error);
    if (error.message === 'Failed to fetch') {
        alert('Connection error. Make sure the backend server is running on port 5000.');
    } else {
        alert('An error occurred: ' + error.message);
    }
}