"""
CARELINK AI - Desktop Application Wrapper
Uses PyWebView to wrap the web app as a desktop application
"""

import webview
import threading
import subprocess
import time
import sys
from pathlib import Path

def start_backend_server():
    """Start Flask backend server"""
    print("🚀 Starting backend server...")
    try:
        subprocess.Popen([sys.executable, 'backend/app.py'])
        time.sleep(2)  # Wait for server to start
    except Exception as e:
        print(f"⚠️  Error starting backend: {e}")

def main():
    print("=== CARELINK AI Desktop Application ===")
    print("Starting application...")
    
    # Start backend server in background
    server_thread = threading.Thread(target=start_backend_server, daemon=True)
    server_thread.start()
    
    # Create WebView window
    window = webview.create_window(
        'CARELINK AI - Healthcare Monitoring System',
        'frontend/index.html',
        width=1200,
        height=800,
        min_size=(800, 600)
    )
    
    webview.start(debug=False)

if __name__ == '__main__':
    main()