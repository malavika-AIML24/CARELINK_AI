"""
CARELINK AI - Flask Backend Server
Provides REST API for patient data and risk prediction
"""

from flask import Flask, jsonify, request
from flask_cors import CORS
import threading
import time
from simulator import PatientsDatabase
from predict import RiskPredictor

app = Flask(__name__)
CORS(app)

# Initialize database and predictor
db = PatientsDatabase()
predictor = RiskPredictor()

# Global variables for simulation
simulation_running = True
simulation_thread = None

def simulation_loop():
    """Background thread that updates patient vitals continuously"""
    while simulation_running:
        db.update_all_patients()
        time.sleep(2)  # Update every 2 seconds

def start_simulation():
    """Start background simulation thread"""
    global simulation_thread
    simulation_thread = threading.Thread(target=simulation_loop, daemon=True)
    simulation_thread.start()
    print("✅ Simulation started")

# ============================================================================
# AUTHENTICATION ENDPOINTS
# ============================================================================

@app.route('/auth/login', methods=['POST'])
def login():
    """Mock login endpoint"""
    data = request.json
    username = data.get('username')
    password = data.get('password')
    role = data.get('role')
    
    # Simple validation
    if username and password and role in ['doctor', 'staff']:
        return jsonify({
            "status": "success",
            "message": "Login successful",
            "user": {
                "username": username,
                "role": role
            }
        }), 200
    
    return jsonify({
        "status": "error",
        "message": "Invalid credentials"
    }), 401

@app.route('/auth/logout', methods=['POST'])
def logout():
    """Logout endpoint"""
    return jsonify({
        "status": "success",
        "message": "Logged out successfully"
    }), 200

# ============================================================================
# PATIENT LIST ENDPOINTS
# ============================================================================

@app.route('/patients', methods=['GET'])
def get_patients_list():
    """Get list of all patients"""
    patients = db.get_patient_list()
    return jsonify({
        "status": "success",
        "patients": patients,
        "total": len(patients)
    }), 200

# ============================================================================
# PATIENT DATA ENDPOINTS
# ============================================================================

@app.route('/patient/<int:patient_id>', methods=['GET'])
def get_patient(patient_id):
    """Get vitals for a specific patient"""
    vitals = db.get_patient(patient_id)
    
    if not vitals:
        return jsonify({
            "status": "error",
            "message": f"Patient {patient_id} not found"
        }), 404
    
    # Get risk prediction
    risk_data = predictor.predict_risk(
        vitals['heart_rate'],
        vitals['temperature'],
        vitals['spo2']
    )
    
    # Combine vitals and risk data
    response = {**vitals, **risk_data}
    
    return jsonify({
        "status": "success",
        "data": response
    }), 200

@app.route('/patients/vitals', methods=['GET'])
def get_all_vitals():
    """Get vitals for all patients with risk predictions"""
    all_patients = db.get_all_patients()
    
    for patient in all_patients:
        risk_data = predictor.predict_risk(
            patient['heart_rate'],
            patient['temperature'],
            patient['spo2']
        )
        patient.update(risk_data)
    
    return jsonify({
        "status": "success",
        "data": all_patients,
        "total": len(all_patients)
    }), 200

# ============================================================================
# HEALTH CHECK
# ============================================================================

@app.route('/health', methods=['GET'])
def health_check():
    """API health check endpoint"""
    return jsonify({
        "status": "healthy",
        "message": "CARELINK AI server is running"
    }), 200

# ============================================================================
# ERROR HANDLING
# ============================================================================

@app.errorhandler(404)
def not_found(error):
    return jsonify({
        "status": "error",
        "message": "Endpoint not found"
    }), 404

@app.errorhandler(500)
def server_error(error):
    return jsonify({
        "status": "error",
        "message": "Internal server error"
    }), 500

# ============================================================================
# STARTUP
# ============================================================================

if __name__ == '__main__':
    print("🚀 Starting CARELINK AI Backend Server...")
    start_simulation()
    app.run(debug=True, host='127.0.0.1', port=5000)